import { Component, OnInit } from '@angular/core';
import * as CanvasJS from '../../canvasjs.min';
@Component({
  selector: 'app-chart1',
  templateUrl: './chart1.component.html',
  styleUrls: ['./chart1.component.css']
})
export class Chart1Component implements OnInit {

  constructor() { }

  ngOnInit(){
    let chart = new CanvasJS.Chart("chartContainer", {
      animationEnabled: true,
      exportEnabled: true,
      title: {
        text: "Medicines with Customers Usage View"
      },
      data: [{
        type: "column",
        dataPoints: [
          { y: 71, label: "Rythmol" },
          { y: 55, label: "Raspberry" },
          { y: 50, label: "ropinirole" },
          { y: 65, label: "Hand Sanitizer" },
          { y: 95, label: "Valsartan Capsules" },
          { y: 68, label: "Therapeutic" },
          { y: 28, label: "Roxicet" },
          { y: 34, label: "Reclast" },
          { y: 14, label: "Valganciclovirmedicine" }
        ]
      }]
    });
      
    chart.render();
    
  }

}
