import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChartComponent } from './chart/chart.component';
import {RouterModule, Routes} from '@angular/router';
import { Chart1Component } from './chart1/chart1.component';

const appRoutes : Routes = [
  {path: 'chart',
   component: ChartComponent
  },
  {path: 'chart1',
   component: Chart1Component
  },
];  
@NgModule({
  declarations: [
    AppComponent,
    ChartComponent,
    Chart1Component,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
