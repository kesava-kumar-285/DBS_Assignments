import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'testApp'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.name).toEqual('kesava');
  });
  it(`Button to have ClickOnMe` ,()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const app= fixture.componentInstance;
    const btn =fixture.debugElement.nativeElement.querySelector("srh");
    btn.click();
    expect(app.name).toEqual('kesava');
    expect(app.age).toEqual(22);  

  });
  it(`check the constructor proper`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('testApp');
  });
  it(`test`,()=>{
    const fixture = TestBed.createComponent(AppComponent);
    const app= fixture.componentInstance;
    expect (app.var).toEqual('content');
  });

  // it('should render title', () => {
  //   const fixture = TestBed.createComponent(AppComponent);
  //   fixture.detectChanges();
  //   const compiled = fixture.nativeElement;
  //   expect(compiled.querySelector('.content span').textContent).toContain('testApp app is running!');
  // });


  it(`Testing a odd_even`, ()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const num = fixture.componentInstance.odd_even(80);
    expect (num).toEqual("even");
  });
  it(`Testing a factorial`, ()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const num = fixture.componentInstance.factorial(9);
    expect (num).toEqual(362880);
  });
  it(`Testing a factorial`, ()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const num = fixture.componentInstance.factorial(0);
    expect (num).toEqual(1);
  });
  it(`Testing a factorial`, ()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const num = fixture.componentInstance.factorial(-8);
    expect (num).toEqual("only greater than zero");
  });
  it(`Testing a divide`, ()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const num = fixture.componentInstance.divide(9,10);
    expect (num).toEqual(0.9);
  });
  it(`Testing a divide`, ()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const num = fixture.componentInstance.divide(9,0);
    expect (num).toEqual(0);
  });
  // it(`should have title THIS IS THE TITLE as the h1 element`,()=>{
  //   const fixture = TestBed.createComponent(AppComponent);
  //   const app =fixture.componentInstance;
  //   const title =fixture.debugElement.query(By.css('h1')).nativeElement;
  //   expect(title.innerHTML).toEqual("This is the title");
  // });

  it(`Button to have ClickOnMe` ,()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const btn =fixture.debugElement.nativeElement.querySelector("#yes-btn");

    expect(btn.innerHTML).toBe('ClickOnMe');
  });

  it(`Button to have ClickOnMe` ,()=>{
    const fixture =TestBed.createComponent(AppComponent);
    const app= fixture.componentInstance;
    const btn =fixture.debugElement.nativeElement.querySelector("#yes-btn");
    btn.click();
    expect(app.userResponse).toEqual('I am in');
  });
});
