import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'testApp';
  var = 'content';
  userResponse:string;
  name:string;
  age:number;
  constructor(){
    this.name="kesava";
    this.age=22;
    alert('Name is:'+this.name);
    alert('Age is:'+this.age);
  }
  fun1(){
    console.log("this is for testing");
  }

  sayYes(){
    this.userResponse ="I am in";
  }
  odd_even (num1: number) : string
  {
    if(num1%2==0){
      return "even";
    }
    else{
      return "odd";
    }
    
  }
divide (num1: number,num2: number) : number
  {
    if(num2==0){
      return 0;
    }
    return num1/num2;
    
  }
a:number;
n:number;
i:number;
factorial(n:number){
  if(n<0){
    return("only greater than zero");
  }
  if(n==0){
    return 1;
  }
  this.a=n;
  this.n=1;
  this.i=1;
  while(this.i<this.a){
    n=n*this.i;
    this.i++;
    }
  return n;
  }

  
}
