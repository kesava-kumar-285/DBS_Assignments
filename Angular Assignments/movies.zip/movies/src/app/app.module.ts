import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TheaterComponent } from './theater/theater.component';
import { MovieComponent } from './movie/movie.component';
import { FormsModule } from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import { MoviesComponent } from './movies/movies.component';
const appRoutes: Routes=[
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'theatre',
    component: TheaterComponent
  },
  {
    path: 'movie',
    component: MovieComponent
  },

]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TheaterComponent,
    MovieComponent,
    MoviesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
