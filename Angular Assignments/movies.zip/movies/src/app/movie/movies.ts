import { NumberValueAccessor } from '@angular/forms';

export class Movies{
    id:number;
    name:string;
    theme:string;
    rating:number;
    photo:string;
    constructor(){}
}