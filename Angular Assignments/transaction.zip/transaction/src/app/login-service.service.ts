import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LoginServiceService {
  @Output() event: EventEmitter<boolean> = new EventEmitter();
  forgotUser: any;
  users: any = [];

  constructor(private httpClient: HttpClient) {
    this.httpClient.get('./assets/users.json').subscribe(
      (data) => {
        this.users = data;
      },
      (error) => {
        console.log('Error: ' + error.message);
      }
    );
  }

  login(email: string, password: string): boolean {
    var flag: boolean = false;
    this.users.forEach((element) => {
      if (element.email === email && element.password === password) {
        flag = true;
        this.event.emit(true);
      }
    });
    return flag;
  }

  retrievePassword(email: string): boolean {
    var flag: boolean = false;
    this.users.forEach((element) => {
      if (element.email === email) {
        this.forgotUser = element;
        flag = true;
      }
    });

    return flag;
  }
}
