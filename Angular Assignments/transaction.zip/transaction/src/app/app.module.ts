import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { EventEmitter } from '@angular/core'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MedicinelistComponent } from './medicinelist/medicinelist.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ForgotComponent } from './forgot/forgot.component';
import { DataComponent } from './data/data.component';
import { ListComponent } from './list/list.component';

@NgModule({
  declarations: [
    AppComponent,
    MedicinelistComponent, 
    LoginComponent, 
    ForgotComponent,
    DataComponent,
    ListComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent],
})
export class AppModule {}
