import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MedicinesService } from '../medicines.service';

@Component({
  selector: 'app-medicinelist',
  templateUrl: './medicinelist.component.html',
  styleUrls: ['./medicinelist.component.css'],
})
export class MedicinelistComponent implements OnInit {
  id: number;
  name: string;
  date: string;
  medicine: string;
  amount: number;
  medicines: any = [];
  p:number=1; 
  constructor(
    private medicineService: MedicinesService,
    private httpClient: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.httpClient.get('../assets/receipt.json').subscribe(
      (data) => {
        if (this.medicineService.userEmail === 'admin@gmail.com') {
          console.log('Email :' + this.medicineService.userEmail);
          this.medicines = data;
          this.medicineService.medicines = data;
        } else if (this.medicineService.userEmail != undefined) {
          console.log('Email present:' + this.medicineService.userEmail);
          var temp: any = data;
          temp.forEach((element) => {
            if (element.email === this.medicineService.userEmail)
              this.medicines.push(element);
          });
        } else {
          console.log('Email undefined:' + this.medicineService.userEmail);
          this.router.navigate(['/login']);
        }
      },
      (error) => {
        console.log('Error has occurred');
        console.log(error);
      }
    );
  }

  sortById(type: string) {
    this.medicines = this.medicineService.sortById(type);
  }

  sortByName(type: string) {
    this.medicines = this.medicineService.sortByName(type);
  }

  sortByDate(type: string) {
    this.medicines = this.medicineService.sortByDate(type);
  }

  sortByMedicine(type: string) {
    this.medicines = this.medicineService.sortByMedicine(type);
  }

  sortByAmount(type: string) {
    this.medicines = this.medicineService.sortByAmount(type);
  }

  filterById() {
    if (this.id == null) this.medicines = this.medicineService.medicines;
    else this.medicines = this.medicineService.filterById(this.id);
  }

  filterByName() {
    this.medicines = this.medicineService.filterByName(this.name);
  }

  filterByDate() {
    this.medicines = this.medicineService.filterByDate(this.date);
  }

  filterByMedicine() {
    this.medicines = this.medicineService.filterByMedicine(this.medicine);
  }

  filterByAmount() {
    if (this.amount == null) this.medicines = this.medicineService.medicines;
    else this.medicines = this.medicineService.filterByAmount(this.amount);
  }

  reset() {
    this.id = null;
    this.name = '';
    this.date = '';
    this.medicine = '';
    this.amount = null;

    this.medicines = this.medicineService.medicines;
  }
}
