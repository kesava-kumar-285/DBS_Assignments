import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginServiceService } from '../login-service.service';
import { MedicinesService } from '../medicines.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  userEmail: string = '';
  flag: boolean = false;

  constructor(
    private loginService: LoginServiceService,
    private medicineService: MedicinesService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  onClickSubmit(data) {
    if (this.loginService.login(data.emailid, data.password)) {
      this.userEmail = data.emailid;
      this.medicineService.userEmail = data.emailid;
      this.router.navigate(['/medicines']);
    } else {
      this.flag = true;
    }
  }
}
