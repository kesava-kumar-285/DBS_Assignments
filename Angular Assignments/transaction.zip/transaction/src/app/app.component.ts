import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from './login-service.service';
import { MedicinesService } from './medicines.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  userEmail: string;
  flag: boolean = false;
  constructor(
    private loginService: LoginServiceService,
    private medicineService: MedicinesService
  ) {}

  ngOnInit() {
    this.loginService.event.subscribe(
      (data) => {
        this.flag = data;
      },
      (error) => {
        console.log(error);
        this.flag = false;
      }
    );
  }

  signOut() {
    this.loginService.event.emit(false);
    this.medicineService.userEmail = undefined;
  }
}
