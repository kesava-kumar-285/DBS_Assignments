import { NumberValueAccessor } from '@angular/forms';

export class Movies{
        id:number;
        name:string;
        date:string;
        list:number;
        quantity:number;
        total:number;
        constructor(){}
}