import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForgotComponent } from './forgot/forgot.component';
import { LoginComponent } from './login/login.component';
import { MedicinelistComponent } from './medicinelist/medicinelist.component';
import { DataComponent } from './data/data.component';
import { ListComponent } from './list/list.component';
const routes: Routes = [
  { path: 'medicines', component: MedicinelistComponent },
  { path: 'login', component: LoginComponent },
  { path: 'forgot', component: ForgotComponent },
  { path: 'data', component: DataComponent },
  { path: 'list', component:  ListComponent  },
  { path: '**', redirectTo: 'login' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
