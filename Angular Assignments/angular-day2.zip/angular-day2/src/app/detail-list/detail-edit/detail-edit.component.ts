import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-edit',
  templateUrl: './detail-edit.component.html',
  styleUrls: ['./detail-edit.component.css']
})
export class DetailEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
