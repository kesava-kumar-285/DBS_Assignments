import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {


  constructor() { }

  showDate():string
  {
    return new Date() + " ";
  }
  showTime():string
  {
    
    return new Date().getHours() + ':' + new Date().getMinutes()+ ":" +new Date().getSeconds() ;
  }
  showDate_Formate():string
  {
    return new Date().toLocaleString().split(',')[0];
  }
  getsum()
  {
  let number1=100;
  let number2=80;
  return number1+number2;
  } 
  getsub()
  {
  let number1=100;
  let number2=80;
  return number1-number2;
  }    
  getmult()
  {
  let number1=100;
  let number2=80;
  return number1*number2;
  }
  getdiv()
  {
  let number1=100;
  let number2=80;
  return number1/number2;
  }   
  getrem()
  {
  let number1=100;
  let number2=80;
  return number1%number2;
  }
  cal_sum(num1:number,num2:number){
    return num1+num2;

  }
  onAddition(num1:number,num2:number){
    let num3=num1+num2;
    return num3;

  }
  onSubtraction(num1:number,num2:number){
    let num3=num1-num2;
    return num3;

  }      
  onMultiplication(num1:number,num2:number){
    let num3=num1*num2;
    return num3;

  }      
  onDivision(num1:number,num2:number){
    let num3=num1/num2;
    return num3;

  }      
  onRemainder(num1:number,num2:number){
    let num3=num1%num2;
    return num3;

  }      
      


}
