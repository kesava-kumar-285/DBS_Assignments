import { TestBed } from '@angular/core/testing';

import { NewCmpService } from './new-cmp.service';

describe('NewCmpService', () => {
  let service: NewCmpService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NewCmpService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
