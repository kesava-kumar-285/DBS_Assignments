export class movie_Book
{
   id:number;
   name:string;
   theme:string;
   rating:string;
   constructor(){}
}
