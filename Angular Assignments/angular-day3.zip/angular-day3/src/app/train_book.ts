export class Book
{
   id:number;
   name:string;
   arrival:string;
   departure:string;
   constructor(){}
}
